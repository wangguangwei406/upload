<?php
define('ROOT_PATH', __DIR__); //网站根目录
define('DEBUG', false);

/**
 *--------------------------------------------------------------
 * 框架初始化文件
 *--------------------------------------------------------------
 */

//是否开启错误调试
if (defined("DEBUG") && DEBUG == true) {
    ini_set('display_errors', 1);
    error_reporting(E_ERROR);
} else {
    error_reporting(0);
}

//设置当前时区
date_default_timezone_set("PRC");

//载入配置文件
require(ROOT_PATH.'/Config/config.php');

//载入框架函数
require(ROOT_PATH.'/common.php');

//开启类自动加载
spl_autoload_register('autoload');

//调用控制器
require(ROOT_PATH.'/Service/Controller.php');
$ctl = new \Service\Controller();
$ctl->init();

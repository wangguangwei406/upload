<?php
/**
 *--------------------------------------------------------------
 * 网站入口文件
 *--------------------------------------------------------------
 */
define('ROOT_PATH', realpath(__DIR__."/../")); //网站根目录
define('DEBUG', false);
define('PHP_SAPI_NAME', php_sapi_name()); //运行模式 cli apache

header("Content-Type:text/html;charset=UTF-8");

// 加载框架初始化文件
require(ROOT_PATH.'/bootstrap.php');

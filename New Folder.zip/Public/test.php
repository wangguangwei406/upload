<?php

$url = 'http://www.markandlona.co.kr/product/244949';
$output = file_get_contents($url); 
var_dump($output);

?>
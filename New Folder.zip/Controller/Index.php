<?php
namespace Controller;

use Service\AddWaterMark;

class Index
{
    public function index()
    {
        echo date('Y-m-d H:i:s');

        /*
        $waterMarkImage = "/home/webpub/Public/watermark-0.png";
        $waterMarkImageSmall = "/home/webpub/Public/watermark-00.png";
        $filename = "/home/KakaoTalk_20210216_213501837_13.jpg";

        $addMark = new AddWaterMark();
        $addMark->setImage($filename);
        $addMark->setWaterMarkImage($waterMarkImage);
        $status = $addMark->run();
        if ($status == false) {
            $addMark->setWaterMarkImage($waterMarkImageSmall);
            $addMark->run();
        }
        */
    }


}

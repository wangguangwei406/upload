<?php
namespace Controller;

use Exception;
use Service\AddWaterMark;
use Service\Authorization;
use Service\DownloadByUrl;
use Service\UploadToYun;
use Throwable;

/**
 * 图片上传
 */
class Upload
{
    protected $expires = 86400; // 24 hours
    protected $start_time = 0;

    public function __construct()
    {
        set_time_limit(0);
        ini_set('memory_limit', '512M');

        $this->header();

        $this->start_time = time();

        $params = isset($_POST) ? $_POST : [];
        $sign = isset($_POST['sign']) ? $_POST['sign'] : "";
        $auth = new Authorization(APP_ID, APP_KEY);
        $status = $auth->validate($sign, $params);
        if (! $status) {
            echo json_encode(array(
                "error"   => -1,
                "message" => "Validate authorization failed.",
                "request" => $params
            ));
            exit();
        }

        if (!isset($_POST['timestamp'])) {
            $status = $this->isDatetime($_POST['timestamp']);
            if (! $status) {
                echo json_encode([
                    "error" => -1,
                    "message" => "datetime format error."
                ]);
                exit();
            }
        }
        $timestamp = $_POST['timestamp'];
        $requestTime = strtotime($timestamp);
        $seconds = abs(time() - $requestTime);
        if ($seconds > $this->expires) {
            echo json_encode([
                "error" => -1,
                "message" => "authorization sign expired!"
            ]);
            exit();
        }
    }

    // 丹徒下载
    public function weburl()
    {
        try {
            if (!isset($_POST['url']) || empty($_POST['url'])) {
                throw new Exception("parameter [url] is empty!");
            }
            if (!isset($_POST['folder']) || empty($_POST['folder'])) {
                throw new Exception("parameter [folder] is empty!");
            }

            $url = trim($_POST['url']);
            $folder = trim($_POST['folder']);

            $data = $this->doAction($folder, $url, -1);
            echo json_encode([
                "error" => 0,
                "data" => $data
            ]);
        } catch (Exception $e) {
            echo json_encode([
                "error" => -1,
                "message" => $e->getMessage()
            ]);
        }
    }


    // 多图下载
    public function url()
    {
        try {
            if (!isset($_POST['urls']) || empty($_POST['urls'])) {
                throw new Exception("parameter [urls] is empty!");
            }
            if (!isset($_POST['image_id']) || empty($_POST['image_id'])) {
                throw new Exception("parameter [image_id] is empty!");
            }
            if (!isset($_POST['folder']) || empty($_POST['folder'])) {
                throw new Exception("parameter [folder] is empty!");
            }
            if (!isset($_POST['transparent'])) {
                $transparent = -1;
            } else {
                $transparent = intval($_POST['transparent']);
            }
            if (isset($_POST['watermark'])) {
                $transparent = intval($_POST['watermark']);
            }

            if (!in_array($transparent, [0, 1, 2, -1])) {
                $transparent = -1;
            }
            $folder = trim($_POST['folder']);
            $urls = explode("{{+}}", $_POST['urls']);
            $ids  = explode(",", $_POST['image_id']);
    
            $result = [];
            foreach ($urls as $index => $url) {
                try {
                    $data = $this->doAction($folder, $url, $transparent);
                    $result[$index] = array_merge([
                        "status" => 0,
                        "image_id" => $ids[$index],
                    ], $data);
                } catch (\Throwable $e) {
                    $result[$index] = [
                        "status" => -1,
                        "message" => $e->getMessage()
                    ];
                }
            }
            echo json_encode([
                "error" => 0,
                "data" => $result
            ]);
        } catch (\Throwable $e) {
            echo json_encode([
                "error" => -1,
                "message" => $e->getMessage()
            ]);
        }
    }

    // 通过网址
    protected function doAction($folder, $url, $transparent = 1)
    {
        switch ($transparent) {
            case 0:
                $waterMarkImage = ROOT_PATH ."/Public/watermark-0.png";
                $waterMarkImageSmall = ROOT_PATH ."/Public/watermark-00.png";
                break;
            case 1:
                $waterMarkImage = ROOT_PATH ."/Public/watermark-1.png";
                $waterMarkImageSmall = ROOT_PATH ."/Public/watermark-11.png";
                break;
            case 2:
                $waterMarkImage = ROOT_PATH ."/Public/watermark-2.png";
                $waterMarkImageSmall = ROOT_PATH ."/Public/watermark-22.png";
                break;
            case -1: // 不加水印
                break;
            default:
                $waterMarkImage = ROOT_PATH ."/Public/watermark-1.png";
                $waterMarkImageSmall = ROOT_PATH ."/Public/watermark-11.png";
        }

        // 下载
        $download = new DownloadByUrl();
        $download->setImage($url);
        $download->setFolder(strtolower($folder));
        $filename = $download->run();

        // 加水印
        if ($transparent >= 0) {
            try {
                $addMark = new AddWaterMark();
                $addMark->setImage($filename);
                $addMark->setWaterMarkImage($waterMarkImage);
                $status = $addMark->run();
                if ($status == false) {
                    $addMark->setWaterMarkImage($waterMarkImageSmall);
                    $addMark->run();
                }
            } catch (\Exception $e) {
            }
        }

        // 上传
        $upload = new UploadToYun();
        $upload->setFilename($filename);
        $data = $upload->run();

        return [
            "pic_original" => $url,
            'url'          => $data['url'],
            'path'         => $data['path'],
            'width'        => $data['width'],
            'height'       => $data['height'],
            'size'         => $data['size'],
            'mime'         => $data['mime'],
        ];
    }

    //写入日志
    protected function addLog($content)
    {
        $filename = RUNTIME_PATH . "/upload/". date("Ymd"). ".log";
        if (!file_exists(dirname($filename))) {
            mkdir(dirname($filename), 0777, true);
        }
        $content = "[".date("Y-m-d H:i:s")."] {$content}";
        file_put_contents($filename, $content.PHP_EOL, FILE_APPEND);
    }

    protected function header()
    {
        $headerArray = array(
            "Origin",
            "X-Requested-With",
            "Content-Type",
            "Accept",
            "Authorization",
        );
        $allowHeader = implode(", ", $headerArray);
        $allowOrigns = [
            "http://admin.fs-mall.com",
            "http://www.fs-mall.com",
            "http://admin.taosmd.cn",
            "http://www.wechain.com",
            "http://www.wechain.co.kr",
            "http://admin.fs", // 本地测试
        ];
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : "";
        if (in_array($origin, $allowOrigns)) {
            header("Access-Control-Allow-Origin: {$origin}");
        }
        header("Content-Type: text/html; charset=utf-8");
        header("Access-Control-Allow-Headers: {$allowHeader}");
        header("Access-Control-Allow-Methods", "POST, PUT, GET, OPTIONS");

        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            exit(json_encode(["error" => 0, "time" => time()]));
        }

        $content_type = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : "";
        $content_type = strtolower($content_type);
        if (strpos($content_type, "application/json") === 0) {
            $rawPostData = file_get_contents("php://input");
            try {
                $json = json_decode($rawPostData, true);
                foreach ($json as $key => $value) {
                    $_POST[$key] = $value;
                }
            } catch (\Exception $e) {
            }
        }
    }


    // 判断是否日期
    public function isDatetime($date, $format = 'Y-m-d H:i:s')
    {
        $unixTime_1 = strtotime($date);
        if (!is_numeric($unixTime_1)) {
            return false;
        }
        $checkDate = date($format, $unixTime_1);
        $unixTime_2 = strtotime($checkDate);
        if ($unixTime_1 == $unixTime_2) {
            return true;
        } else {
            return false;
        }
    }
}

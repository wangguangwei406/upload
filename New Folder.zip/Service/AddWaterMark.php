<?php
namespace Service;

use Imagick;

/**
 * 添加水印
 */
class AddWaterMark
{
    protected $waterMarkImage = "";
    protected $image          = "";

    public function setWaterMarkImage($waterMarkImage)
    {
        $this->waterMarkImage = $waterMarkImage;
    }

    public function setImage($image)
    {
        $this->image = $image;
    }

    public function run()
    {
        $image = new Imagick();
        $image->readImage($this->image);
        $watermark = new Imagick();
        $watermark->readImage($this->waterMarkImage);

        // how big are the images?
        $iWidth = $image->getImageWidth();
        $iHeight = $image->getImageHeight();

        $wWidth = $watermark->getImageWidth();
        $wHeight = $watermark->getImageHeight();


        if ($iHeight < $wHeight || $iWidth < $wWidth) {
            return false;
        }

        // calculate the position
        $x = ($iWidth - $wWidth) / 2;
        $y = ($iHeight - $wHeight) / 2;
        $image->compositeImage($watermark, Imagick::COMPOSITE_OVER, $x, $y);

        return $image->writeImage($this->image);
    }
}

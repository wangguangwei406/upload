<?php
namespace Service;

/**
 * 认证
*/
class Authorization
{
    private $client_id;
    private $secret;
    private $format = "json";
    private $signType = "md5";
    private $version = "1.0";

    public function __construct($client_id, $secret)
    {
        $this->client_id = $client_id;
        $this->secret    = $secret;
    }

    // 验证签名
    public function validate($sign, $args)
    {
        $sign = $this->sign($args);
        if (isset($args['sign']) && $args['sign'] == $sign) {
            return true;
        }
        return false;
    }

    // 签名
    public function sign($args)
    {
        $args = $this->__filter($args);
        ksort($args);

        $stringToBeSigned = $this->secret;
        foreach ($args as $k => $v) {
            if (is_array($v)) {
                ksort($v);
                $v = json_encode($v, JSON_UNESCAPED_UNICODE);
            }
            if ("@" != substr($v, 0, 1)) {
                $stringToBeSigned .= "$k$v";
            }
        }
        unset($k, $v);
        $stringToBeSigned .= $this->secret;

        return strtoupper(md5($stringToBeSigned));
    }

    // 创建请求数据
    public function create($args = [])
    {
        $args['client_id'] = $this->client_id;
        $args['timestamp'] = date('Y-m-d H:i:s');
        $args['format']    = $this->format;
        $args['sign_type'] = $this->signType;
        $args['version']   = $this->version;
        $args['sign']      = $this->sign($args);
        return $args;
    }

    // 过滤掉空值
    private function __filter($args)
    {
        $result = array();
        foreach ($args as $key => $val) {
            if ($key == "sign" || $key == "sign_type" || $val === "") {
                continue;
            } else {
                $result[$key] = $val;
            }
        }
        return $result;
    }
}

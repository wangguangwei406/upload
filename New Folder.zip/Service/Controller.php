<?php
namespace Service;

// 控制器类
class Controller
{
    protected $class = "Index";
    protected $method = "index";

    public function __construct()
    {
        if (php_sapi_name() == 'cli') {
            $r = $GLOBALS['argv'][1];
        } else {
            $r = isset($_GET['r']) ? $_GET['r'] : "";
        }

        if (! empty($r)) {
            $arr = explode(':', $r);
            $this->class = $arr[0];
            if (isset($arr[1]) && !empty($arr[1])) {
                $this->method = $arr[1];
            } else {
                $this->method = 'index';
            }
        }
    }

    // 页面控制器最初入口
    public function init()
    {
        $class = 'Controller\\'. ucfirst($this->class);
        $cls = new $class();
        if (method_exists($class, $this->method)) {
            $method = $this->method;
            $cls->$method();
        }
        exit();
    }
}

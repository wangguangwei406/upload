<?php
namespace Service;

require_once(ROOT_PATH.'/libs/upyun/upyun.class.php');

use Exception;

/**
 * 上传
 */
class UploadToYun
{
    protected $filename; // 本地文件地址

    public function __construct($conf = [])
    {
        if (!empty($conf)) {
            $bucket   = $conf['BUCKET'];
            $username = $conf['USERNAME'];
            $password = $conf['PASSWORD'];
            $domain   = $conf['DOMAIN'];
        } else {
            // 默认调用图片空间
            global $_G;
            $bucket   = $_G['UPYUN'][0]['BUCKET'];
            $username = $_G['UPYUN'][0]['USERNAME'];
            $password = $_G['UPYUN'][0]['PASSWORD'];
            $domain   = $_G['UPYUN'][0]['DOMAIN'];
        }
        
        $endpoint = 'v0.api.upyun.com';
        
        $this->domain = $domain;
        $this->upyunModel = new \UpYun($bucket, $username, $password, $endpoint);
    }

    public function setFilename($filename)
    {
        $this->filename = $filename;
    }

    public function run()
    {
        if (!file_exists($this->filename)) {
            throw new Exception("file is not exist, file: {$this->filename}");
        }
        $filepath = str_replace(UPLOAD_PATH, "", $this->filename);
        $filepath = ltrim($filepath, "/");
    
        $info = getimagesize($this->filename);
        if ($info) {
            list($width, $height, $mime_type) = $info;
            switch ($mime_type) {
                case 1:
                    $mime = 'image/gif';
                    break;
                case 2:
                    $mime = 'image/jpeg';
                    break;
                case 3:
                    $mime = 'image/png';
                    break;
                default:
                    throw new Exception("file type is not in [png, jpg, gif], file: {$this->filename}");
                    break;
            }
        } else {
            throw new Exception("file is not image, file: {$this->filename}");
        }
        
        $opts = array(
            \UpYun::CONTENT_MD5 => md5(file_get_contents($this->filename))
        );
        
        $fh = fopen($this->filename, 'rb');
        try {
            $this->upyunModel->writeFile("/{$filepath}", $fh, true, $opts); //上传图片，自动创建目录
            return [
                'url'    => "{$this->domain}/{$filepath}",
                'path'   => $filepath,
                'width'  => $width,
                'height' => $height,
                'size'   => filesize($this->filename),
                'mime'   => $mime,
            ];
        } catch (Exception $e) {
            throw new Exception("file upload failed, ". $e->getMessage());
        }
        fclose($fh);
    }
}

<?php
namespace Service;

use Exception;

/**
 * 图片下载
 */
class DownloadByUrl
{
    protected $folder = "product";
    protected $image;

    public function setImage($image)
    {
        $image = rawurldecode($image);
        $image = trim($image);
        if (stripos($image, "http://") === 0 || stripos($image, "https://") === 0) {
            $this->image = $image;
            return;
        }

        if (stripos($image, "//") === 0) {
            $this->image = "http:{$image}";
            return;
        }

        throw new Exception("image url is error, url: {$image}");
    }

    public function setFolder($folder)
    {
        $folder = str_replace("detail/", "details/", $folder);
        $this->folder = trim($folder);
    }

    /**
     * 返回图片本地路径
     *
     * @return string
     */
    public function run()
    {
        // 特殊字符转义
        $image = str_replace('&amp;', '&', $this->image);
        $image = $this->filterURL($image);

        // 文件报存地址
        $filename = $this->newname($this->folder, $this->image);

        // 尝试下载5次
        $counter = 0;
        $status = false;
        while ($status == false && $counter < 5) {
            try {
                $this->download($image, $filename);
                $status = true;
                break;
            } catch (Exception $e) {
                $this->addLog($e->getMessage() . ", counter: {$counter}, URL: {$image}");
                $message = $e->getMessage();
                $counter += 1;
            }

            if ($counter == 4) {
                $content = file_get_contents($image);
                if ($content) {
                    file_put_contents($filename, $content);
                    $status = true;
                    break;
                }
            }
        }

        if ($status) {
            // 判断图片格式，如果为webp则转换成jpg
            try {
                $info = getimagesize($filename);
                if ($info) {
                    list($width, $height, $mime_type) = $info;
                    switch ($mime_type) {
                        case 1:
                            break;
                        case 2:
                            break;
                        case 3:
                            break;
                        default:
                            $filename = $this->formatToJPG($filename);
                    }
                } else {
                    $filename = $this->formatToJPG($filename);
                }
            } catch (\Exception $e) {
                throw new Exception("无法识别的图片文件！{$filename}");
            }

            return $filename;
        }
        
        throw new Exception("{$message}, url: {$image}");
    }

    protected function formatToJPG($filename)
    {
        $ext = substr($filename, -4, 4);
        $ext = strtolower($ext);
        if (in_array($ext, [".jpg", ".gif", "webp", ".png"])) {
            $newname = trim(substr($filename, 0, -4), ".");
            $newname = $newname.".png";
        } else {
            $newname = $filename.".png";
        }
        
        /*
        $image = new \Imagick();
        $image->readImage(realpath($filename));
        $image->setImageFormat("jpg");
        $image->writeImage($newname);
        $image->clear();
        unset($image);
        */

        $file = realpath($filename);
        system("convert {$file} {$newname}");

        return $newname;
    }

    protected function filterURL($url)
    {
        $data = parse_url($url);
        $array = explode("/", $data['path']);
        foreach ($array as $key => $value) {
            if (preg_match("/^[0-9a-zA-Z_\-\=\$\.]+$/", $value) == 0) {
                $array[$key] = rawurlencode($value);
            }
        }
        $data['path'] = ltrim(implode("/", $array), "/");

        $link = $data['scheme']."://". $data['host'] ."/". $data['path'];
        if (isset($data['query'])) {
            $link .= "?". $data['query'];
        }
        return $link;
    }

    // 将网络图片下载到服务器
    protected function download($image, $filename)
    {
        $headers = $this->headers();

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $image);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36');
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 300);
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 5);

        if (strpos($image, "https://") === 0) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // https请求 不验证证书和hosts
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        }

        $content   = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $file_size = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD); // 取 Content-length
        $errno     = curl_errno($ch);
        curl_close($ch);
        if ($http_code >= 200 && $http_code < 300) { //状态码 200到300
        } else {
            throw new Exception("image download failed, http_code: {$http_code}");
        }
        if ($errno > 0) {
            throw new Exception("image download failed, errno: {$errno}");
        }
        if ($file_size > 0 && strlen($content) < $file_size) {
            throw new Exception("The image is not downloaded completely");
        }

        if ($content) {
            $file = fopen($filename, 'w');
            if ($file) {
                fwrite($file, $content);
                fclose($file);
                chmod($filename, 0777);

                return true;
            } else {
                throw new Exception("Open file failed, url: {$image}");
            }
        }
        
        throw new Exception("image download failed, content is empty or not found, url: {$image}");
    }

    // 新建文件名
    public function newname($folder, $image)
    {
        $ext = substr($image, -4, 4);
        $ext = trim($ext, '.');
        $ext = strtolower($ext);
        if (!in_array($ext, ["jpg", "jpeg", "png", "gif"])) {
            $ext = "jpg";
        }
        
        $date = date('Y/md');
        $time = date('His');
        
        $dir = ROOT_PATH."/Public/uploads/{$folder}/{$date}";
        $dir = str_replace(" ", "", $dir);
        if (!file_exists($dir)) {
            mkdir($dir, 0777, true);
        }
        return $dir ."/{$time}" . md5(uniqid()) .'.'. $ext;
    }

    protected function addLog($content)
    {
        $filename = RUNTIME_PATH . "/download/". date("Ymd"). ".log";
        if (!file_exists(dirname($filename))) {
            mkdir(dirname($filename), 0777, true);
        }
        $content = "[".date("Y-m-d H:i:s")."] {$content}";
        file_put_contents($filename, $content.PHP_EOL, FILE_APPEND);
    }


    protected function headers()
    {
        return [
            "content-type: application/x-www-form-urlencoded; charset=UTF-8",
            "Expect:"
        ];
    }
} 

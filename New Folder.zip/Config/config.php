<?php
//配置常量
define('UPLOAD_PATH', ROOT_PATH.'/Public/uploads'); //图片上传目录
define('RUNTIME_PATH', ROOT_PATH.'/Runtime'); //运行时目录

// 签名验证
define("APP_ID", '23235754');
define("APP_KEY", 'b55b025b59206abcaee9ebd0159a98de');

//公共配置
$_G = array();
$_G['UPYUN'][0] = array(
    'BUCKET'   => 'fsprd',
    'USERNAME' => 'operator',
    'PASSWORD' => 'www.fs-mall.com',
    'DOMAIN'   => 'http://img.taosmd.cn',
);

$_G['UPYUN'][1] = [
    'BUCKET'   => 'wechain',
    'USERNAME' => 'operator',
    'PASSWORD' => 'www.fs-mall.com',
    'DOMAIN'   => 'http://img01.taosmd.cn',
];

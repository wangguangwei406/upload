<?php
/**
 *--------------------------------------------------------------
 * 框架基础函数库
 *--------------------------------------------------------------
 */

// 自动加载类文件
function autoload($class)
{
    $class = str_replace('\\', '/', $class);
    $class = trim($class, '/');

    $array = explode('/', $class);
    $file = ROOT_PATH .'/'. implode('/', $array).'.php';

    if (file_exists($file)) {
        include_once($file);
    }
}
